<?php
$extension=pathinfo($_POST['filename'],PATHINFO_EXTENSION);
if(in_array($extension,array('jpg','jpeg','png','gif','bmp')))
{
    $image_content = file_get_contents($_FILES['file']['tmp_name']);
    $store_name=uniqid().'.'.$extension;
    file_put_contents($store_name,$image_content);
    $size=getimagesize($store_name);
    if($size[0]>0 && $size[1]>0)
    {
        echo '存储的文件名为：'.$store_name;
    }
}

?>